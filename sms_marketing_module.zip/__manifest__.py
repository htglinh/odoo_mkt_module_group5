{
    'name': 'SMS Marketing',
    'version': '1.0',
    'category': 'Marketing',
    'summary': 'Manage SMS marketing campaigns with A/B testing and scheduling',
    'depends': ['base'],
    'data': [],
    'installable': True,
    'application': True,
}